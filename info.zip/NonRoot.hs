module NonRoot where

adjacent :: [Integer]
adjacent = []

localMass :: Integer
localMass = 0

aggregate_mass :: Integer
aggregate_mass = 0

sent_mass :: [Integer]
sent_mass = []

received_mass :: [Integer]
received_mass = []

levels :: [Integer]
levels = []

broadcast :: Bool
broadcast = False