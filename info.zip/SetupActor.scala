class SetupActor
{
  // send new message and fail message - new message will arrive before fail message

  // environment - setupActor -> rootnode in system
  // send new and fail message to nodes inside of the system
  
}
